Lab 3

Part 1:

I made the repository public so it can be viewed by anyone.
The link is: https://github.com/SteveCDozo/ITWS4500.git

I included the image 'part1.png' to show that I created the local and remote
repositories, and that I shared it with you and Professor Plotka.


Part 2:

I included the image 'part2.png' to show that our group made a remote repository
on GitHub, shared it with you and Professor Plotka, and I have cloned it locally. 

The link for it is: https://github.com/wtg/elex.git

I included the image 'mantis.png' to show that I installed Mantis on my localhost
server.